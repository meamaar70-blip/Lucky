# نصب Lucky روی VPS ویندوز — قدم به قدم

کل مسیر ۲۰ دقیقه است. فقط چهار چیز لازم داری: **Node.js**، **فایل‌های برنامه**،
**اجرای سرویس** و **آدرس HTTPS**.

---

## قدم ۰ — چه فایل‌هایی لازم است؟

فقط این‌ها را روی ویندوز کپی می‌کنی (بقیه لازم نیست):

```
package.json
package-lock.json
server\            ← کل پوشه (موتور برنامه)
public\            ← کل پوشه (رابط کاربری، آیکن‌ها، فونت‌ها)
deploy\windows\    ← اسکریپت‌های همین راهنما
samples\           ← اختیاری (یک PDF نمونه برای تست)
```

راحت‌ترین راه: فایل `lucky-server-windows.zip` را دانلود کن (کنار همین راهنما
در مخزن است)؛ دقیقاً همین ساختار داخلش هست.

پوشهٔ مقصد پیشنهادی: `C:\lucky`

> ❌ پوشهٔ `node_modules` را کپی نکن — روی خود سرور ساخته می‌شود.
> ❌ `android`، `docs`، `scripts`، `preview.html` هم لازم نیست.

---

## قدم ۱ — نصب Node.js 20

1. در مرورگر همان VPS برو به <https://nodejs.org/en/download>
2. نسخهٔ **LTS 20.x → Windows Installer (.msi) → 64-bit** را دانلود و نصب کن
   (Next, Next, Finish — هیچ گزینه‌ای را لازم نیست عوض کنی).
3. پنجرهٔ **Command Prompt** باز کن (کلید ویندوز → تایپ `cmd` → Enter) و بزن:

```bat
node -v
npm -v
```

باید مثلاً `v20.18.0` ببینی. اگر «شناخته نشد» گفت، cmd را ببند و دوباره باز کن.

---

## قدم ۲ — گذاشتن فایل‌ها

1. فایل zip را در `C:\` کپی کن، راست‌کلیک → **Extract All** → مقصد `C:\`
2. اگر پوشه‌ای با نام دیگر باز شد، اسمش را بگذار `C:\lucky` (یا محتویاتش را داخل
   `C:\lucky` بریز؛ طوری که `C:\lucky\package.json` وجود داشته باشد).
3. **نصب بسته‌ها — راحت‌ترین راه:** روی `deploy\windows\setup.bat` دابل‌کلیک کن.
   خودش پوشهٔ درست را پیدا می‌کند، وجود فایل‌ها و Node را چک می‌کند و در آخر
   می‌گوید «همه‌چیز نصب شد».

   اگر ترجیح می‌دهی دستی بزنی، اول مطمئن شو در پوشهٔ درست هستی:

```bat
cd /d C:\lucky
dir package-lock.json
npm ci --omit=dev
```

   `dir` باید `package-lock.json` را نشان بدهد؛ اگر «File Not Found» داد یعنی
   فایل‌ها جای دیگری باز شده‌اند (معمولاً `C:\lucky\lucky-server-windows\`).

---

## قدم ۳ — اجرای آزمایشی

روی `deploy\windows\start-lucky.bat` دابل‌کلیک کن.
پنجرهٔ سیاه باز می‌ماند و می‌نویسد `Lucky Study روی http://0.0.0.0:3000 بالا آمد`.

روی خود سرور، مرورگر را باز کن و برو به:

```
http://localhost:3000
```

اگر برنامه باز شد، نصف راه رفته‌ای. این پنجره را ببند (Ctrl+C) تا برویم سراغ سرویس.

> داده‌ها در `C:\lucky-data` ذخیره می‌شوند (قابل تغییر در `start-lucky.bat`).
> پشتیبان‌گیری = کپی همین پوشه.

---

## قدم ۴ — باز کردن پورت‌ها

1. روی `deploy\windows\firewall.bat` راست‌کلیک → **Run as administrator**
2. در پنل ارائه‌دهندهٔ VPS (پنل مدیریت سرور) هم پورت‌های **80** و **443** را باز کن.
   اگر پنل «Security Group / Firewall» دارد، همان‌جاست.

تست از گوشی: `http://IP-سرور:3000` را در مرورگر گوشی باز کن (همان وای‌فای لازم نیست،
اینترنت گوشی هم کافی است). اگر باز شد، پورت ۳۰۰۰ از بیرون در دسترس است.

---

## قدم ۵ — HTTPS (برای نصب روی گوشی و اعلان‌ها)

بدون HTTPS، اپ نصب‌شدنی (PWA) و اعلان‌ها کار نمی‌کنند. دو راه داری:

### راه الف — خودکار: `setup-https.bat`

روی `deploy\windows\setup-https.bat` دابل‌کلیک کن. خودش:

1. `caddy.exe` را دانلود می‌کند (اگر نبود)
2. آی‌پی عمومی سرور را می‌گیرد و دامنهٔ `lucky-<آی‌پی>.sslip.io` می‌سازد
3. `Caddyfile` را می‌نویسد و Caddy را اجرا می‌کند

آخر کار آدرس `https://lucky-…sslip.io` را چاپ می‌کند؛ همان را در اپ وارد کن.
(پنجره را باز نگه دار، یا بعداً `caddy.exe start` بزن تا به‌صورت سرویس اجرا شود.)

### راه الف-۲ — دستی (اگر دامنهٔ خودت را داری)

1. `caddy.exe` را بگیر — مطمئن‌ترین راه، آخرین نسخهٔ GitHub است:

   ```powershell
   $r = Invoke-RestMethod 'https://api.github.com/repos/caddyserver/caddy/releases/latest'
   $a = $r.assets | Where-Object { $_.name -like '*windows_amd64.zip' }
   Invoke-WebRequest -UseBasicParsing $a[0].browser_download_url -OutFile caddy.zip
   tar.exe -xf caddy.zip
   .\caddy.exe version
   ```

   اگر `tar.exe` نبود: `Expand-Archive .\caddy.zip . -Force`
   (راه جایگزین: <https://caddyserver.com/download> → Windows / amd64)
2. `caddy.exe` را در `C:\lucky\deploy\windows\` بگذار.
3. فایل `Caddyfile` همان پوشه را با Notepad باز کن و خط اول را عوض کن:
   - با دامنه: `lucky.yourdomain.ir {`
   - بدون دامنه: آی‌پی سرورت را با خط تیره بنویس، مثلاً `lucky-82-12-34-56.sslip.io {`
     (این دامنه‌های رایگان خودکار به همان آی‌پی می‌روند)
4. اجرا:

```bat
cd C:\lucky\deploy\windows
caddy.exe run --config Caddyfile
```

اولین بار ۱۰ تا ۳۰ ثانیه طول می‌کشد تا گواهی بگیرد. بعد این را باز کن:

```
https://lucky-82-12-34-56.sslip.io/api/health
```

باید `{"ok":true,...}` ببینی.

5. برای اینکه Caddy هم خودکار بالا بیاید: در همان پوشه

```bat
caddy.exe start
```

> اگر IIS روی پورت ۸۰ نشسته باشد، Caddy نمی‌تواند گواهی بگیرد: سرویس IIS را
> متوقف کن (`net stop W3SVC`) یا از راه ب استفاده کن.

### راه ب — Cloudflare Tunnel (بدون باز کردن پورت، بدون گواهی)

اگر دامنه داری و نمی‌خواهی با فایروال/گواهی درگیر شوی:

```bat
winget install --id Cloudflare.cloudflared
cloudflared tunnel --url http://localhost:3000
```

یک آدرس موقت `https://xxxx.trycloudflare.com` چاپ می‌شود که همان لحظه کار می‌کند
(برای همیشه ماندگار نیست؛ برای دائمی‌کردن، تونل نام‌دار در پنل Cloudflare بساز).

---

## قدم ۶ — اجرای دائمی (سرویس ویندوز)

روی `deploy\windows\install-service.bat` راست‌کلیک → **Run as administrator**.
از این پس Lucky با هر ری‌استارت ویندوز خودکار بالا می‌آید.

```bat
schtasks /Run   /TN "Lucky"     :: اجرای فوری
schtasks /End   /TN "Lucky"     :: توقف
schtasks /Delete /TN "Lucky" /F :: حذف سرویس
```

نکته: اگر مسیر Node را جای دیگری نصب کردی، داخل `install-service.bat` مسیر
`C:\Program Files\nodejs\node.exe` را اصلاح کن.

---

## قدم ۷ — وصل کردن اپ اندروید

1. APK را نصب کن (`apk/lucky.apk` در مخزن، یا از Releases).
2. آدرس را وارد کن:

```
https://lucky-82-12-34-56.sslip.io
```

3. تمام. برای عوض کردن آدرس بعداً: در صفحهٔ اصلی، دکمهٔ بازگشت گوشی → «تغییر آدرس سرور».

اگر می‌خواهی APK از پیش پر باشد: آدرس را به من بده تا متغیر `LUCKY_SERVER_URL`
را ست کنم و APK تازه بسازم؛ یا خودت در GitHub → Settings → Variables → Actions
متغیر را بساز و یک تغییر کوچک در `android/**` پوش کن.

---

## به‌روزرسانی نسخه

```bat
cd C:\lucky
:: فایل‌های تازه را از zip جدید روی همین پوشه کپی کن (data جدا است و دست نمی‌خورد)
npm ci --omit=dev
schtasks /End /TN "Lucky"
schtasks /Run /TN "Lucky"
```

---

## نکته‌های فنی

- **متن‌های فارسی داخل فایل‌های `.bat`:** با `chcp 65001` درست نمایش داده می‌شوند.
  اگر باز هم به‌هم‌ریخته دیدی، فقط ظاهر پیام است؛ خود برنامه سالم اجرا می‌شود.
- **`npm audit`:** چند اخطار مربوط به `canvas` را می‌بینی که وابستگی *اختیاری*
  `pdfjs-dist` است. ما آن را نصب نمی‌کنیم (فایل `.npmrc` با `omit=optional`)،
  چون فقط متن PDF را می‌خوانیم و رندر تصویر لازم نداریم. پس این اخطارها در
  نسخهٔ نصب‌شده وجود ندارند.
- **آپلود PDF** با `multer 2.x` و سقف پیش‌فرض ۲۰۰ مگابایت در Caddy بررسی شده است.

## اگر مشکلی پیش آمد

| نشانه | علت و راه‌حل |
|---|---|
| `node` شناخته نمی‌شود | cmd را ببند و باز کن؛ یا Node را دوباره نصب کن و گزینهٔ Add to PATH را تیک بزن |
| `npm ci` خطای شبکه | DNS/فیلتر سرور؛ تست کن: `npm config set registry https://registry.npmjs.org/` |
| متن فارسی bat به‌هم‌ریخته | `chcp 65001` در فایل هست؛ اگر نشد فقط ظاهر است، برنامه سالم است |
| `http://localhost:3000` باز نمی‌شود | پورت اشغال است: `netstat -ano | findstr :3000` و پروسهٔ مزاحم را ببند |
| از گوشی باز نمی‌شود، از خود سرور می‌شود | فایروال ویندوز (`firewall.bat`) یا فایروال پنل VPS |
| Caddy گواهی نمی‌گیرد | پورت ۸۰ بسته است یا IIS روی آن است؛ پورت را باز کن یا `net stop W3SVC` |
| آپلود PDF خطا می‌دهد | سقف آپلود: در Caddyfile مقدار `max_size` را زیاد کن |
| بعد از ری‌استارت سایت بالا نمی‌آید | سرویس ساخته نشده: `install-service.bat` را با Run as administrator اجرا کن |

---

## فایل‌های این پوشه

| فایل | کار |
|---|---|
| `start-lucky.bat` | اجرای دستی برنامه (برای تست) |
| `install-service.bat` | ساخت تسک ویندوز برای اجرای خودکار پس از بوت |
| `firewall.bat` | باز کردن پورت‌های ۸۰/۴۴۳/۳۰۰۰ در فایروال ویندوز |
| `Caddyfile` | تنظیمات HTTPS خودکار (قبل از استفاده، آدرس خط اول را عوض کن) |
